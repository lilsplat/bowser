from django.contrib import admin
from courses.models import UserProfile, Student

admin.site.register(UserProfile)
admin.site.register(Student)
