# course_dists_script.sh

echo "The script starts now"
echo "Hi, $USER!"
# echo
# echo
# # echo "Entering sqlite now"

# FILE=all_courses_fall2014.txt
# i=0
# while read line
# do
#     # display $line or do somthing with $line
# 	echo "$line"
# done < $FILE



# # sqlite3 test.db  "insert into n (f,l) values ('john','smith');"
# echo "Done"